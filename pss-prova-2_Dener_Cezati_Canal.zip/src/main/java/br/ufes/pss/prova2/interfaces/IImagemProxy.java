package br.ufes.pss.prova2.interfaces;

import javax.swing.ImageIcon;

public interface IImagemProxy {

    ImageIcon exibir();

    void exibirToString();
}
